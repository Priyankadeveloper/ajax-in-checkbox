<?php
include_once('../include/function.php');
$db= new functions();

if(isset($_REQUEST['action']) && $_REQUEST['action'] == 'check_emails')
{
	$u_email = $_REQUEST['email'];
	
	$sql = "select * from user where u_email = '".$u_email."'";
	
	$run = $db->query($sql);
	if(mysqli_num_rows($run) > 0)
	{
		echo 0;
		
	} 
	else 
	{
		echo 1;
	}
}
else if(isset($_REQUEST['action']) && $_REQUEST['action'] == 'save_files')
{
	$data = $_REQUEST['img']; // Your data 'data:image/png;base64,AAAFBfj42Pj4';
    list($type, $data) = explode(';', $data);
    list(, $data)      = explode(',', $data);
	$data = base64_decode($data);
	$new_name = rand(10000,99999).time().'.png';
	$new_name1 = rand(10000,99999).time().'233.png';
	$path = '../profile/'.$new_name;
	$path2 = '../profile/'.$new_name1;
	//file_put_contents($path, $data);
	if(file_put_contents($path, $data))
	{
		$dsr=$db->compressImage($path,$path2,20);
		$data1['result']=1;
		$data1['image']=$new_name1;
	}
	else 
	{
		$data1['result']=0;
	}
	echo json_encode($data1);
}
else if(isset($_REQUEST['action']) && $_REQUEST['action'] == 'save_filesindb_new')
{
  $data = $_REQUEST['img']; // Your data 'data:image/png;base64,AAAFBfj42Pj4';

    list($type, $data) = explode(',', $data);
    //list(, $data)      = explode(',', $data);
	$data = base64_decode($data);
	$new_name = rand(10000,99999).time().'.png';
	$path = '../profile/'.$new_name;
	//file_put_contents($path, $data);
	if(file_put_contents($path, $data))
	{
		$db->query("insert into tbl_profile set user_id='".$_SESSION["user_id"]."',a_id='".$_REQUEST['a_id']."',p_img='".$new_name."'");
		
		$p_id=$db->insert_id();
		$data1['result']=1;
		$data1['image']=$new_name;
		$data1['p_id']=$p_id;
		
		
		
	}
	else 
	{
		$data1['result']=0;
	}
	echo json_encode($data1);
  }
else if(isset($_REQUEST['action']) && $_REQUEST['action'] == 'save_filesindb')
{
	
	 $data = $_REQUEST['img']; // Your data 'data:image/png;base64,AAAFBfj42Pj4';
	
    list($type, $data) = explode(';', $data);
    list(, $data)      = explode(',', $data);
	$data = base64_decode($data);
	$new_name = rand(10000,99999).time().'.png';
	$new_names = rand(10000,99999).time().'233.png';
	$path = '../profile/'.$new_name;
	$path2 = '../profile/'.$new_names;
	//file_put_contents($path, $data);
	if(file_put_contents($path, $data))
	{
		$dsr=$db->compressImage($path,$path2,90);
		
		$db->query("insert into tbl_profile set user_id='".$_SESSION["user_id"]."',a_id='".$_REQUEST['a_id']."',p_img='".$new_names."'");
		
		$p_id=$db->insert_id();
		$data1['result']=1;
		$data1['image']=$new_names;
		$data1['p_id']=$p_id;
		
		
		
	} 
	else 
	{
		$data1['result']=0;
	}
	echo json_encode($data1);
}
else if(isset($_REQUEST['action']) && $_REQUEST['action'] == 'del_area_img')
{
	$db->query("DELETE FROM  tbl_profile WHERE p_id='".$_REQUEST['id']."'");
	echo"1";
}
else if(isset($_REQUEST['action']) && $_REQUEST['action'] == 'sign_up')
{
	extract($_REQUEST);
		
		$u_cameraid = implode(',' ,$_REQUEST['u_cameraid']);
		$u_lensid = implode(',' ,$_REQUEST['u_lensid']);
		$u_accessories = implode(',' ,$_REQUEST['u_accessories']);
		$u_other_equipment = implode(',' ,$_REQUEST['u_other_equipment']);
		$category=implode(',',$_REQUEST['chk1']);
	
		$uploaddir = '../profile/';
	     $u_img=end(explode(".",$_FILES['u_img']['name']));
	     $file_name=time().".".$u_img;
	     $uploadfile = $uploaddir . basename($file_name);
	     $filename='';
	    if(move_uploaded_file($_FILES['u_img']['tmp_name'], $uploadfile)) 
		{
			$filename=", u_img = '".$file_name."'";
		}
		
		 $sql = "insert into user set u_f_name = '".$u_f_name."',u_l_name= '".$u_l_name."',u_phone_number= '".$u_phone_number."', u_email = '".$u_email."',u_address='".$u_address."',u_lat='".$lat."',u_lng='".$lng."', u_password = '".$u_password."',u_shoot_hours='".$u_shoot_hours."',u_cameraid='$u_cameraid',u_lensid='$u_lensid',u_accessories='$u_accessories',u_other_equipment='$u_other_equipment',u_pyears='".$u_pyears."',u_description='".htmlentities($u_description,ENT_QUOTES)."',u_exp_summry='".htmlentities($u_exp_summry,ENT_QUOTES)."',u_s_photography='".htmlentities($u_s_photography,ENT_QUOTES)."',u_lovejob='".htmlentities($u_lovejob,ENT_QUOTES)."',u_shoottype_que='".htmlentities($u_shoottype_que,ENT_QUOTES)."',u_special_shoot='".htmlentities($u_special_shoot,ENT_QUOTES)."',u_fav_place='".htmlentities($u_fav_place,ENT_QUOTES)."',u_awardlist='".htmlentities($u_awardlist,ENT_QUOTES)."',u_fun_fact='".htmlentities($u_fun_fact,ENT_QUOTES)."',u_online_portfolio='".$u_online_portfolio."',u_insta='".$u_insta."',u_fb_page='".$u_fb_page."',u_yelp='".$u_yelp."',u_twitter='".$u_twitter."', u_type = '1', u_status = '1',u_category ='$category',u_email_status=1,profile_status=0,u_wallet=0 $filename"; 
		
		$run=$db->query($sql);
		  
		if($run)
		{
			$lastid = $db->insert_id();
			foreach($_REQUEST['chk1'] as $ses)
			{
			if($ses)
			{
				 $i = 0;
				 $feis="filesets_".$ses;
				 foreach($_REQUEST[$feis] as $ff_se)
				 {
					 //$ff_sel;
					   
						$db->query("insert into tbl_profile set user_id='".$lastid."',a_id='".$ses."',p_img='".$ff_se."'");
					 $i++;
				}
					
			}
		    }
			
			$_SESSION["user_id"]=$lastid;
			$_SESSION["user_type"]=1;
			$_SESSION['is_user_logged_in']=true;
			$_SESSION['email']=$u_email;
			$_SESSION['name']=$u_f_name; 
			
			$subject ="Phoshot: Expert Registration!"; 
			$contant= 'Hello, '.$u_f_name.' <br><br>';
			$contant.='<p class="text-center">Thank you for taking the time to apply to become a Partner Photographer on our marketplace! </p><p></p><p>Due to a large volume of applicants, it may take up to 3 days before we can get back to you, so please hang tight and well let you know as soon as weve had a chance to review your application.</p>
			';
			
			$test = $db->MailSend($u_email,$subject,$contant);
			$data1=$db->get_admin_data();
			$r=mysqli_fetch_assoc($data1);
			$email = $r['mail_email'];
			$subject ="Phoshot: Expert Registration!"; 
			$contant= 'Hello, Admin <br><br>';
			$contant.='<p class="text-center">We have a new application request for Expert Photographer.Please check admin panel for more information. </p>';
			
			$test = $db->MailSend($email,$subject,$contant);
			$json['status'] = 1;
			
			
		}
		else
		{
			$json['status'] = 0;
			
		}
		
	
	$json['gf'] = $sql;
	echo json_encode($json);
}

else if(isset($_REQUEST['action']) && $_REQUEST['action']=='loginform')
	{
             $u_email=$_REQUEST['u_email'];
			 $u_password = $_REQUEST['u_password'];
		    $query = "select * from user where u_email = '$u_email' and u_password = '$u_password' and u_status='1'";
			$data=$db->query($query);
			if (mysqli_num_rows($data)>0) 
			{
				$row=mysqli_fetch_array($data);
				$_SESSION['user_id'] =  $row['user_id'];
				$_SESSION['is_user_logged_in']=true;
				$_SESSION["user_type"]=$row["u_type"];
				$_SESSION['email']=$row['u_email'];
			    $_SESSION['name']=$row['u_f_name'];
 				
				
				$json['status'] = 1;
			}
			else
			{
				$json['status'] = 0;
			}
	echo json_encode($json);	
		
	}
	
else if(isset($_REQUEST['action']) && $_REQUEST['action'] == 'forget_password')
{
	$u_email = $db->real_string($_REQUEST['u_email']);
	$sql = "select * from user where u_email = '".$u_email."'";
	$run = $db->query($sql); 

	if(mysqli_num_rows($run) == 1)
	{
		$user = mysqli_fetch_assoc($run);
		
		  $name=$user['u_f_name'];

		  $subject ="Phoshot: Forgot Password!"; 
		  $contant = 'Hello, '.$name.' <br><br>';
		  $contant .='<p class="text-center">This is an automated message . If you did not recently initiate the Forgot Password process, please disregard this email.<p>';
		  $contant .='<p class="text-center">
						You indicated that you forgot your login password. We can generate a temporary password for you to log in with, then once logged in you can change your password to anything you like.</p>'; 
						$contant .='<p class="text-center">Password: <b>'.$user['u_password'].'</b></p>';
			$test = $db->MailSend($u_email,$subject,$contant);
			
			$json['status'] = 1;
			$_SESSION['msg'] = '<p class="alert alert-success">You password has been sent successfully at your registered mail address!</p>';
	}
	else
	{
		$json['status'] = 2;
	}
	echo json_encode($json);
}

else if(isset($_REQUEST['action']) && $_REQUEST['action']=='changePassword')
	{
    $sql = "select * from user where user_id = '".$_REQUEST['user_id']."'";
	$run = $db->query($sql);
	$row = mysqli_fetch_assoc($run);
	if($row['u_password'] == $_REQUEST['Current_Password'])
	{
		$sql = "update user set u_password = '".$_REQUEST['New_Password']."' where user_id = '".$_REQUEST['user_id']."'";
		$run = $db->query($sql);
		echo 1;
	}
	else
	{
		echo 0;
	}
}
else if(isset($_REQUEST['action']) && $_REQUEST['action']=='basicdetails')
{
	$uploaddir = '../profile/';
	     $u_img=end(explode(".",$_FILES['u_img']['name']));
	     $file_name=time().".".$u_img;
	     $uploadfile = $uploaddir . basename($file_name);
	     $filename='';
	    if(move_uploaded_file($_FILES['u_img']['tmp_name'], $uploadfile)) 
		{
			$filename=", u_img = '".$file_name."'";
		}
	
        $u_f_name = $_REQUEST['u_f_name'];
		$u_l_name = $_REQUEST['u_l_name'];
		$u_phone_number = $_REQUEST['u_phone_number'];
		$u_address = $_REQUEST['u_address'];
		$u_lat = $_REQUEST['u_lat'];
		$u_lng = $_REQUEST['u_lng'];
		$u_shoot_hours = $_REQUEST['u_shoot_hours'];
		$early_hours = $_REQUEST['early_hours'];
		$user_id = $_REQUEST['user_id'];
		 $sql = "UPDATE user SET u_f_name='$u_f_name',u_l_name='$u_l_name',u_phone_number='$u_phone_number',u_address='$u_address',u_lat='$u_lat',u_lng='$u_lng',u_shoot_hours='$u_shoot_hours',early_hours='$early_hours' $filename  WHERE user_id = '$user_id'";
		$result = $db->query($sql); 
		if($result==true)
		{
			$_SESSION['suc_msg'] = "Success Profile has been updated Successfully.";
			
		}else
		{
			$_SESSION['suc_msg'] = "Something went wrong .";
			
		}
		header('location:../profile.php?tab=tab1');
}

else if(isset($_REQUEST['action']) && $_REQUEST['action']=='equipment')
{
        $u_cameraid = implode(',' ,$_REQUEST['u_cameraid']);
		$u_lensid = implode(',' ,$_REQUEST['u_lensid']);
		$u_accessories = implode(',' ,$_REQUEST['u_accessories']);
		$u_other_equipment = implode(',' ,$_REQUEST['u_other_equipment']);
		$user_id = $_REQUEST['user_id'];
		 $sql = "UPDATE user SET u_cameraid='$u_cameraid',u_lensid='$u_lensid',u_accessories='$u_accessories',u_other_equipment='$u_other_equipment' WHERE user_id = '$user_id'";
		$result = $db->query($sql); 
		if($result==true)
		{
			$_SESSION['suc_msg'] = "Success Profile has been updated Successfully.";
			
		}else
		{
			$_SESSION['suc_msg'] = "Something went wrong .";
			
		}
		header('location:../equipment.php');
}

else if(isset($_REQUEST['action']) && $_REQUEST['action']=='experience')
{
	extract($_REQUEST);
        
		 $user_id = $_REQUEST['user_id'];
		 $sql = "UPDATE user SET u_pyears='".$u_pyears."',u_description='".htmlentities($u_description,ENT_QUOTES)."',u_exp_summry='".htmlentities($u_exp_summry,ENT_QUOTES)."',u_s_photography='".htmlentities($u_s_photography,ENT_QUOTES)."',u_lovejob='".htmlentities($u_lovejob,ENT_QUOTES)."',u_shoottype_que='".htmlentities($u_shoottype_que,ENT_QUOTES)."',u_special_shoot='".htmlentities($u_special_shoot,ENT_QUOTES)."',u_fav_place='".htmlentities($u_fav_place,ENT_QUOTES)."',u_awardlist='".htmlentities($u_awardlist,ENT_QUOTES)."',u_fun_fact='".htmlentities($u_fun_fact,ENT_QUOTES)."' WHERE user_id = '$user_id'";
		$result = $db->query($sql);
		if($result==true)
		{
			$_SESSION['suc_msg'] = "Success Profile has been updated Successfully.";
			
		}else
		{
			$_SESSION['suc_msg'] = "Something went wrong .";
			
		}
		header('location:../experience.php');
}

else if(isset($_REQUEST['action']) && $_REQUEST['action']=='portfolio')
{
	extract($_REQUEST);
        
		 $user_id = $_REQUEST['user_id'];
		 $sql = "UPDATE user SET u_online_portfolio='".$u_online_portfolio."',u_insta='".$u_insta."',u_fb_page='".$u_fb_page."',u_yelp='".$u_yelp."',u_twitter='".$u_twitter."' WHERE user_id = '$user_id'";
		$result = $db->query($sql); 
		if($result==true)
		{
			$_SESSION['suc_msg'] = "Success Profile has been updated Successfully.";
			
		}else
		{
			$_SESSION['suc_msg'] = "Something went wrong .";
			
		}
		header('location:../portfolio.php');
}

else if(isset($_REQUEST['action']) && $_REQUEST['action']=='setavailability')
{
	
	    //$weekday = implode(',' ,$_REQUEST['weekdays']);
		
		
	    $user_id = $_REQUEST['user_id'];
        $sql2 = "DELETE FROM set_availability  where user_id='$user_id'";
		$result1 = $db->query($sql2); 		
		foreach ($_REQUEST['weekdays'] as $weekday){		
		$test= 'availability_time'.$weekday;
		$availability_time = implode(',' ,$_REQUEST[$test]);
		$sql = "Insert into set_availability SET weekdays='$weekday',availability_time='$availability_time',user_id='$user_id', status='1'";
		$result = $db->query($sql); 
		$_SESSION['suc_msg'] = "Setavailability has been inserted successfully.";
		}
	   header('location:../availability.php');
}

else if(isset($_REQUEST['action']) && $_REQUEST['action']=='exceptions')
{
	     $user_id = $_REQUEST['user_id'];		 
	    $sql1 = "delete from set_availability where user_id='$user_id' and status='0'";
		$result1 = $db->query($sql1);
	    $exception_date= implode(',',$_REQUEST['exception_date']);
		$i='0';
		foreach ($_REQUEST['exception_date'] as $excdate){
		      
	    $ececption_from =  $_REQUEST['ececption_from'][$i];
		$ececption_to = $_REQUEST['ececption_to'][$i];
		$ececption_note = $_REQUEST['ececption_note'][$i];
	    		 		
	    $sql = "Insert into set_availability SET exception_date='$excdate', ececption_from='$ececption_from',ececption_to='$ececption_to',ececption_note='".htmlentities($ececption_note,ENT_QUOTES)."',user_id='$user_id', status='0'";
		$result = $db->query($sql);
		if($result==true)
		{
			$_SESSION['suc_msg'] = "Exceptions has been inserted successfully.";
			
		}else
		{
			$_SESSION['suc_msg'] = "Something went wrong .";
			
		}
	 $i++; }
		header('location:../availability.php');
}

else if(isset($_REQUEST['action']) && $_REQUEST['action']=='shot_package')
{
	$time=$_REQUEST['time'];
	$category=$_REQUEST['category'];
	$data=$db->GetpackageTime($time,$category);
	if(mysqli_num_rows($data)==0)
	{
		?>
		<p class="alert alert-danger">No Package available.<input type="hidden" value="" /></p>
		<?php
	}
	else 
	{
		while($rows1=mysqli_fetch_assoc($data))
		{
			?>
			<div class="box-input">
			<div class="radio img_link_1 other-radio">
			  <label>
				<img src="img/img_23.png" class="img_radu">
				<input type="radio" value="<?php echo $rows1['p_id']; ?>" name="packages"><span>Bussiness <?php echo $rows1['p_title']; ?></span> 
				<p class="price-tag">$<?php echo $rows1['p_price']; ?></p>
				<p><?php echo $rows1['p_description']; ?></p></label>
				
			</div>
			</div>
			<?php
			
		}
	}
}
else if(isset($_REQUEST['action']) && $_REQUEST['action']=='neext_dicws')
{
	$tabs=$_REQUEST['tabs'];
	if($tabs==0)
	{
		?>
	<!--<h1>Is your shoot for business or personal?</h1>
	  <div class="box-input">
		<div class="radio img_link_1">
		  <label>
			<img src="img/img_23.png" class="img_radu">
        <input type="radio" value="business" name="shot_type" >Bussiness</label>
		</div>
		
		<div class="radio img_link_1">
     
		  <label>
			<img src="img/img_22.png" class="img_radu">
			<input type="radio" value="personal"  name="shot_type" >Personal</label>
		</div>
	  </div>-->
	<?php } 
	else if($tabs==1)
	{  
		?>
		<h1>What do you need to shoot?</h1>
		<span class="alertmsg<?php echo $tabs; ?>" style="display:none;">Please choose what do you need to shoot!</span> 
		<div class="row">
		<div class="box-input">
		
		<?php
		$data=$db->get_category_list();
		while($row=mysqli_fetch_assoc($data))
		{
			?>
			
			<div class="col-sm-6" style="margin: 0;">
				<div class="radio img_link_1">
				  <label><input type="radio" value="<?php echo $row['cat_id']; ?>" name="category" ><img class="img_radu" src="admin/img/cat_icon/<?php echo $row['cat_icon']; ?>" /> <?php echo $row['cat_name']; ?></label>
				</div>
			</div>
			<?php
		}
		?>
	</div>
	</div>
		<?php
	}
	else if($tabs==2)
	{
		?>
		<h1>Where is your shoot going to be held?</h1>
		<span class="alertmsg<?php echo $tabs; ?>" style="display:none;">Please tell us where is your shoot going to be held!</span> 
		<div class="box-input">
			<input id="pac-input" placeholder="Enter Address" name="address" class="form-control">  
		</div>
		<div class="map_sections">
			<div class="box-input box-input_en">
				  
			</div>
			<div id="map" style="height:400px; "></div>
			<div id="infowindow-content" >
			  <img src="" width="16" height="16" id="place-icon">
			  <span id="place-name"  class="title"></span><br>
			  <span id="place-address"></span>
			</div>
		</div>
		<?php
		
	}
	else if($tabs==3)
	{
		if(isset($_SESSION["user_id"]))
		{
			?>
			<h1>Please choose a shoot package:</h1>
			<input type="hidden" value="1" id="comes_shot" />
			<span class="alertmsg<?php echo $tabs; ?>" style="display:none;">Please choose a shoot package!</span>
					
				<?php 	
					$datas=$db->Get_packagesByCat($_REQUEST['category']);	  
					if(mysqli_num_rows($datas))
					{
						?>
				<ul class="nav nav-tabs pricingg-tta" role="tablist">
					<li role="presentation" class="active col-sm-6 col-xs-12"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">I need all photos</a></li>
					<li class=" col-sm-6 col-xs-12" role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">I need the lowest booking fees</a></li>
				</ul>
					<?php } ?>
					<?php 	
					$datas=$db->Get_packagesByCat($_REQUEST['category']);	  
					if(mysqli_num_rows($datas))
					{
						?>	
			<!-- Tab panes -->
		  <div class="tab-content">
			<div role="tabpanel" class="tab-pane active" id="home">
				<div class="immner">
					<div class="row">
					<?php $package= $db->allpackagedetails123($_REQUEST['category']);
					$l=1;
					     while ($rows=mysqli_fetch_assoc($package)){
						 ?>
							<div class="pricing-detail">
							
								<div class="radio img_link_1 bbbb12112">
				                <label>
								<?php if($rows["p_id"]=='11'){ ?>
							<div class="most-popular">
								Most Popular
							</div>
							<?php } ?>
									<img src="img/1.png">
				                	<input type="radio" value="<?php echo $rows['p_id']; ?>" name="packages" >
									<h2><?php echo $rows['p_title'];?></h2>
									<?php if ($rows['p_time']==30){?>
										<h4><?php echo $rows['p_time'];?> min									   
										| $<?php echo $rows['p_price'];?></h4>
									<?php } else{ ?>
									    <h4><?php echo $rows['p_time'];?> hr									   
										| $<?php echo $rows['p_price'];?></h4>
									<?php } ?>
									<div class="decsc-pricing">
										<p><?php echo $rows['p_description'];?></p>
										<p>Image enhancement included</p>
									</div></label>
								</div>
					         </div>
						 <?php $l++; } ?>
					</div>
				</div>
			</div>
			<div role="tabpanel" class="tab-pane" id="profile">
			
				<div class="immner">
					<div class="row">
					<?php $package1= $db->packagedetails123($_REQUEST['category']);
					$l=1;
					     while ($rows=mysqli_fetch_assoc($package1)){
						 ?>
						<div class="pricing-detail">
						
								<div class="radio img_link_1 bbbb12112">
				                <label>
								<?php if($rows["p_id"]=='5'){ ?>
							<div class="most-popular">
								Most Popular
							</div>
							<?php } ?>
									<img src="img/1.png">
				                	<input type="radio" value="<?php echo $rows['p_id']; ?>" name="packages" >
									<h2><?php echo $rows['p_title'];?></h2>
									<?php if ($rows['p_time']==30){?>
										<h4><?php echo $rows['p_time'];?> min									   
										| $<?php echo $rows['p_price'];?></h4>
									<?php } else{ ?>
									    <h4><?php echo $rows['p_time'];?> hr									   
										| $<?php echo $rows['p_price'];?></h4>
									<?php } ?>
									<div class="decsc-pricing">
										<p><?php echo $rows['p_description'];?></p>
										<p>Image enhancement included</p>
									</div></label>
								</div>
					         </div>
						 <?php $l++; } ?>
					</div>
				</div>
			</div>
		  </div>	
		  <div class="box-input">
			<div class="package_start">
			</div>
		  </div>&@shoot		
		<?php
						
			}
			else 
			{
				echo "<p class='alert alert-danger'>No pakages Available</p>";
			}
			?>
					&@shoot
					<?php
				//echo "&@shoot";
				die;
		}
		
		else 
		{
			if(isset($_REQUEST['u_email']) && $_REQUEST['u_email']!='')
			{
				
			if(isset($_REQUEST['before_check']) && $_REQUEST['before_check']!='' && ($_REQUEST['password']!='' || ($_REQUEST['u_f_name']!='' && $_REQUEST['u_password']!=''))	)
			{
			$ches=$_REQUEST['before_check'];
			if($ches=='log')
			{
				$q="select * from user where u_email='".$_REQUEST['u_email']."' and u_password='".$_REQUEST['password']."'";
				$query1=$db->query($q);
				if(mysqli_num_rows($query1))
				{
					$row2=mysqli_fetch_assoc($query1);
					$u_f_name=$row2['u_f_name'];
					$user_id=$row2['user_id'];
				}
				else 
				{
					echo "nots&@2";
					die;
				}
			}
			else if($ches=='create')
			{
				$sqs="insert into user set u_email='".$_REQUEST['u_email']."',u_phone_number='".$_REQUEST['u_phone_number']."',u_f_name='".$_REQUEST['u_f_name']."',u_l_name='".$_REQUEST['u_l_name']."',u_type=2,u_status=1,u_password='".$_REQUEST['u_password']."'";
				$query1=$db->query($sqs);
				$u_f_name=$_REQUEST['u_f_name'];
				$user_id=$db->insert_id();
			}
			if($user_id)
			{
				$_SESSION["user_id"]=$user_id;
				$_SESSION["user_type"]=2;
				$_SESSION['is_user_logged_in']=true;
				$_SESSION['email']=$_REQUEST['u_email'];
				$_SESSION['name']=$u_f_name;
				?>
				 <li><a><?php echo $u_f_name ?></a></li>
				<li><a href="dashboard.php" class="logo"><img src="profile/user_images.png" width="30" height="30"></a></li>
				<li class="btn-top"><a href="logout.php">Logout</a></li>||
				<h1>Please choose a shoot package:</h1>
				<?php 	
					$datas=$db->Get_packagesByCat($_REQUEST['category']);	  
					if(mysqli_num_rows($datas))
					{
						?>
				<ul class="nav nav-tabs pricingg-tta" role="tablist">
					<li role="presentation" class="active col-sm-6 col-xs-12"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">I need all photos</a></li>
					<li class=" col-sm-6 col-xs-12" role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">I need the lowest booking fees</a></li>
				</ul>
					<?php } ?>
				<input type="hidden" value="1" id="comes_shot" /> 
			<span class="alertmsg<?php echo $tabs; ?>" style="display:none;">Please choose a shoot package!</span>
			<?php 	
					$datas=$db->Get_packagesByCat($_REQUEST['category']);	  
					if(mysqli_num_rows($datas))
					{
						?>	
			<!-- Tab panes -->
		  <div class="tab-content">
			<div role="tabpanel" class="tab-pane active" id="home">
				<div class="immner">
					<div class="row">
					<?php $package= $db->allpackagedetails123($_REQUEST['category']);
					$l=1;
					     while ($rows=mysqli_fetch_assoc($package)){
						 ?>
							<div class="pricing-detail">
							
								<div class="radio img_link_1 bbbb12112">
				                <label>
								<?php if($rows["p_id"]=='11'){ ?>
							<div class="most-popular">
								Most Popular
							</div>
							<?php } ?>
									<img src="img/1.png">
				                	<input type="radio" value="<?php echo $rows['p_id']; ?>" name="packages" >
									<h2><?php echo $rows['p_title'];?></h2>
									<?php if ($rows['p_time']==30){?>
										<h4><?php echo $rows['p_time'];?> min									   
										| $<?php echo $rows['p_price'];?></h4>
									<?php } else{ ?>
									    <h4><?php echo $rows['p_time'];?> hr									   
										| $<?php echo $rows['p_price'];?></h4>
									<?php } ?>
									<div class="decsc-pricing">
										<p><?php echo $rows['p_description'];?></p>
										<p>Image enhancement included</p>
									</div></label>
								</div>
					         </div>
						 <?php $l++; } ?>
					</div>
				</div>
			</div>
			<div role="tabpanel" class="tab-pane" id="profile">
			
				<div class="immner">
					<div class="row">
					<?php $package1= $db->packagedetails123($_REQUEST['category']);
					$l=1;
					     while ($rows=mysqli_fetch_assoc($package1)){
						 ?>
						<div class="pricing-detail">
						
								<div class="radio img_link_1 bbbb12112">
				                <label>
								<?php if($rows["p_id"]=='5'){ ?>
							<div class="most-popular">
								Most Popular
							</div>
							<?php } ?>
									<img src="img/1.png">
				                	<input type="radio" value="<?php echo $rows['p_id']; ?>" name="packages" >
									<h2><?php echo $rows['p_title'];?></h2>
									<?php if ($rows['p_time']==30){?>
										<h4><?php echo $rows['p_time'];?> min									   
										| $<?php echo $rows['p_price'];?></h4>
									<?php } else{ ?>
									    <h4><?php echo $rows['p_time'];?> hr									   
										| $<?php echo $rows['p_price'];?></h4>
									<?php } ?>
									<div class="decsc-pricing">
										<p><?php echo $rows['p_description'];?></p>
										<p>Image enhancement included</p>
									</div></label>
								</div>
					         </div>
						 <?php $l++; } ?>
					</div>
				</div>
			</div>
		  </div>	
		  <div class="box-input">
			<div class="package_start">
			</div>
		  </div>&@shoot		
		<?php
						
			}
			else 
			{
				echo "<p class='alert alert-danger'>No pakages Available</p>";
			}
		echo "&@shoot";
		die;
		}
			
			
		}
		else 
		{
			$sql="select * from user where u_email='".$_REQUEST['u_email']."'";
			$query=$db->query($sql);
			if(mysqli_num_rows($query))
			{
				$row1=mysqli_fetch_assoc($query);
				if($row1['u_type']==1)
				{
					echo "nan";
					die;
				}
				else 
				{
					?>
					<h1>First let's get your details</h1>
					  <h4>Enter a valid email address to get pricing and save your booking.</h4>
					  
					  <div class="box-input">
						<input placeholder="Type email address" value="<?php echo $_REQUEST['u_email']; ?>" id="check_emails" name="u_email" class="form-control">
					  </div>
					<div class="box-input">
						<input placeholder="Enter Password" type="password" name="password" class="form-control">
						<input type="hidden" value="log" id="checks_4" />
					</div>&@1 
					<?php
				}
				?>
				<?php
			}
			else 
			{
				?>
				<h1>First let's get your details</h1>
				<h4>Enter a valid email address to get pricing and save your booking.</h4>
			  
				  <div class="box-input">
					<input placeholder="Type email address" value="<?php echo $_REQUEST['u_email']; ?>" id="check_emails" name="u_email" class="form-control">
				  </div>
				  <div class="row">
				  	<div class="col-sm-12">
				  		<div class="box-input">
					<input placeholder="Enter Full Name " type="text" name="u_f_name" class="form-control">
				</div> 
				  	</div>
				 <!-- 	<div class="col-sm-6">
				  		
				<div class="box-input">
					<input placeholder="Enter Last Name" type="text" name="u_l_name" class="form-control">
					<input type="hidden" value="create" id="checks_4" />
			   </div>
				  	</div>-->
				  </div>
				  <div class="row">
				  	<div class="col-sm-6">
				  		<div class="box-input">
					<input placeholder="Enter Phone Number" type="text" name="u_phone_number" class="form-control phonevalidation">
					
			   </div>
				  	</div>
				  	<div class="col-sm-6">
				  		 <div class="box-input">
						<input placeholder="Enter Password" type="password" name="u_password" class="form-control">
						<input type="hidden" value="create" id="checks_4" />
					</div>
				  	</div>
				  </div>
				
			   
			  &@1
				<?php
			}
		}
		} else {
		?>
		  <h1>First let's get your details</h1>
		  <h4>Enter a valid email address to get pricing and save your booking.</h4>
		  
		  <div class="box-input">
			<input placeholder="Type email address" id="check_emails" name="u_email" class="form-control">
		  </div>&@non 
	   <?php
		}
		}
	} 
	else if($tabs==4)
	{
		?>
		<h3 class="text-center">Select Date</h3>
		<input type="hidden" class="selected_date" value="<?php echo date('Y/m/d'); ?>" name="booking_date" />
        <div id="demo2"></div>
		<?php
	}
	else if($tabs==14)
	{
		
		if(isset($_REQUEST['before_check']) && $_REQUEST['before_check']!='' && ($_REQUEST['password']!='' || ($_REQUEST['u_f_name']!='' && $_REQUEST['u_l_name']!='' && $_REQUEST['u_password']!='')))
		{
			$ches=$_REQUEST['before_check'];
			if($ches=='log')
			{
				$q="select * from user where u_email='".$_REQUEST['email']."' and u_password='".$_REQUEST['password']."'";
				$query1=$db->query($q);
				if(mysqli_num_rows($query1))
				{
					$row2=mysqli_fetch_assoc($query1);
					$u_f_name=$row2['u_f_name'];
					$user_id=$row2['user_id'];
				}
				else 
				{
					echo "nan&@2";
					die;
				}
			}
			else if($ches=='create')
			{
				$sqs="insert into user set u_email='".$_REQUEST['email']."',u_f_name='".$_REQUEST['u_f_name']."',u_l_name='".$_REQUEST['u_l_name']."',u_type=2,u_status=1,u_password='".$_REQUEST['u_password']."'";
				$query1=$db->query($sqs);
				$u_f_name=$_REQUEST['u_f_name'];
				$user_id=$db->insert_id();
			}
			if($user_id)
			{
				$_SESSION["user_id"]=$user_id;
				$_SESSION["user_type"]=2;
				$_SESSION['is_user_logged_in']=true;
				$_SESSION['email']=$_REQUEST['email'];
				$_SESSION['name']=$u_f_name;
				?>
				 <li><a><?php echo $u_f_name ?></a></li>
				<li><a href="dashboard.php" class="logo"><img src="profile/" width="30" height="30"></a></li>
				<li class="btn-top"><a href="logout.php">Logout</a></li>||
				<h1>How long will your shoot be?</h1>
				<?php 	
					$datas=$db->Get_packagesByCat($_REQUEST['category']);	  
					if(mysqli_num_rows($datas))
					{
						
						while($rows=mysqli_fetch_assoc($datas))
						{
					?>
					  <div class="box-input">
						<div class="radio">
						  <label><input type="radio" <?php if($i==0) { echo "checked"; } ?> value="<?php echo $rows['p_time']; ?>" name="shot_time" ><?php echo $rows['p_time']; if($rows['p_time']=='30') echo "min"; else echo "Hr."; ?></label>
					  </div>
					  </div>
					<?php
					   
						}
						
					}
					else 
					{
						echo "<p class='alert alert-danger'>No pakages Available</p>";
					}
				echo "&@4";
				die;
			}
			
			
		}
		else 
		{
			$sql="select * from user where u_email='".$_REQUEST['email']."'";
			$query=$db->query($sql);
			if(mysqli_num_rows($query))
			{
				$row1=mysqli_fetch_assoc($query);
				if($row1['u_type']==1)
				{
					echo "nan";
					die;
				}
				else 
				{
					?>
					
					<h1>First let's get your details</h1>
					  <h4>Enter a valid email address to get pricing and save your booking.</h4>
					  
					  <div class="box-input">
						<input placeholder="Type email address" value="<?php echo $_REQUEST['email']; ?>" id="check_emails" name="u_email" class="form-control">
					  </div>
					<div class="box-input">
						<input placeholder="Enter Password" type="password" name="password" class="form-control">
						<input type="hidden" value="log" id="checks_4" />
					</div>&@1 
					<?php
				}
				?>
				<?php
			}
			else 
			{
				?>
				<h1>First let's get your details</h1>
				<h4>Enter a valid email address to get pricing and save your booking.</h4>
			  
				  <div class="box-input">
					<input placeholder="Type email address" value="<?php echo $_REQUEST['email']; ?>" id="check_emails" name="u_email" class="form-control">
				  </div>
				  <div class="row">
				  	<div class="col-sm-6">
				  		<div class="box-input">
					<input placeholder="Enter First Name" type="text" name="u_f_name" class="form-control">
				</div> 
				  	</div>
				  	<div class="col-sm-6">
				  		<div class="box-input">
					<input placeholder="Enter Last Name" type="text" name="u_l_name" class="form-control">
					
			   </div>
				  	</div>
				  </div>
				
				
			   <div class="box-input">
						<input placeholder="Enter Password" type="password" name="u_password" class="form-control">
						<input type="hidden" value="create" id="checks_4" />
				</div>&@1
				<?php
			}
		}
		
	}
	else if($tabs==5)
	{
		?>
		<h3 class="text-center">Select Time</h3>
		<span class="alertmsg<?php echo $tabs; ?>" style="display:none;">Please choose shoot time!</span> 
		<?php
				$week = array('Monday');
				//foreach is more readable
				$k=1;
				foreach ($week as $dayName) {
					?>
					<div class="row" >
						<div class="border_2">
						<div class="border_3">
						<div id="week<?php echo $k; ?>" >
						<div class="col-sm-12">
						<div class="row Morning_dic_1">
					<div class="col-sm-4">
						<label>Morning</label>
					<div>
				<?php 
					$startTime = date(strtotime($day." 7:00"));
					$endTime = date(strtotime($day." 12:00"));

					$timeDiff = round(($endTime - $startTime)/60/60);

					$startHour = date("G", $startTime);
					$endHour = $startHour + $timeDiff; 

					for ($i=$startHour; $i <= $endHour; $i++)
					{
						 for ($j = 0; $j <= 45; $j+=30)
							{
									$time = $i.":".str_pad($j, 2, '0', STR_PAD_LEFT);
									$valh=(date(strtotime($day." ".$time)) <= $endTime) ? date("g:ia", strtotime($day." ".$time)): "";
									if($valh)
									{
                                ?>
								
								
						        <div class="searchable-container">
                               <div data-toggle="buttons" class="btn-group bizmoduleselect">
                                 <label class="btn btn-default <?php echo $select1 ?>" >
								 
                                    <div class="bizcontent">
                                    <input  type="radio" class="all_radios" name="booking_time"  autocomplete="off" value="<?php echo (date(strtotime($day." ".$time)) <= $endTime) ? date("g:ia", strtotime($day." ".$time)): ""; ?>" />
                                    <h5><?php echo (date(strtotime($day." ".$time)) <= $endTime) ? date("g:ia", strtotime($day." ".$time))."<br>" : ""; ?></h5>
                                   </div>
								 
                                 </label>
                               </div>
                              </div>
									<?php  } }
					      }
					?>
					</div>
					</div>

					<div class="col-sm-4">
					<label>Afternoon</label>
					<div>
				<?php 
					$startTime = date(strtotime($day." 12:30"));
					$endTime = date(strtotime($day." 17:30"));

					$timeDiff = round(($endTime - $startTime)/60/60);

					$startHour = date("G", $startTime);
					$endHour = $startHour + $timeDiff; 

					for ($i=$startHour; $i <= $endHour; $i++)
					{
						 for ($j = 0; $j <= 45; $j+=30)
							{
									$time = $i.":".str_pad($j, 2, '0', STR_PAD_LEFT);
									$valh=(date(strtotime($day." ".$time)) <= $endTime) ? date("g:ia", strtotime($day." ".$time)): "";
									if($valh)
									{									
									?>
									
                                <div class="searchable-container">                               
                               <div data-toggle="buttons" class="btn-group bizmoduleselect">
                                 <label class="btn btn-default">
                                     <div class="bizcontent">
                                    <input type="radio" class="all_radios" name="booking_time" autocomplete="off" value="<?php echo (date(strtotime($day." ".$time)) <= $endTime) ? date("g:ia", strtotime($day." ".$time)): ""; ?>" />
                                    <h5><?php echo (date(strtotime($day." ".$time)) <= $endTime) ? date("g:ia", strtotime($day." ".$time))."<br>" : ""; ?></h5>
                                   </div>
                                 </label>
                               </div>
                              </div>
							<?php } }
					}
					?>
					</div>
					</div>
					<div class="col-sm-4">
					<label>Evening</label>
					<div>
					<?php 
					$startTime = date(strtotime($day." 18:00"));
					$endTime = date(strtotime($day." 23:00"));

					$timeDiff = round(($endTime - $startTime)/60/60);

					$startHour = date("G", $startTime);
					$endHour = $startHour + $timeDiff; 

					for ($i=$startHour; $i <= $endHour; $i++)
					{
						 for ($j = 0; $j <= 45; $j+=30)
							{
									$time = $i.":".str_pad($j, 2, '0', STR_PAD_LEFT);
									$valh=(date(strtotime($day." ".$time)) <= $endTime) ? date("g:ia", strtotime($day." ".$time)): "";
									if($valh)
									{		
                                  ?>
					          <div class="searchable-container">                          
                               <div data-toggle="buttons" class="btn-group bizmoduleselect">
                                 <label class="btn btn-default">
                                     <div class="bizcontent">
                                    <input type="radio" class="all_radios" name="booking_time"  autocomplete="off" value="<?php echo (date(strtotime($day." ".$time)) <= $endTime) ? date("g:ia", strtotime($day." ".$time)): ""; ?>" />
                                    <h5><?php echo (date(strtotime($day." ".$time)) <= $endTime) ? date("g:ia", strtotime($day." ".$time))."<br>" : ""; ?></h5>
                                   </div>
                                 </label>
                               </div>
                            </div>
						<?php			
							} }
					}
					?>	
					</div>
					</div>
						</div>
					</div>
				





					



					</div>
					</div>
					</div>
					</div>
					<?php $k++;
                   } 	
	}
	else if($tabs==6)
	{
	?>
		<h1>Choose a photographer</h1>
		<div class="">
		<?php
  		$vals=date('Y-m-d',strtotime($_REQUEST['booking_date'])); 
	    $time=$_REQUEST['booking_time'];
		$time1=date('G:i',strtotime($time));
		$date=$vals;
		$today_day=date('l',strtotime($date));
		$dpl1="select user_id from set_availability where status=0 and exception_date='$date' and '$time1'>=ececption_from and '$time1'<=ececption_to";
		
		$dql="select a.* from set_availability as a INNER JOIN user as u ON (a.user_id = u.user_id) where u.u_email_status=1 AND u.u_status=1 AND u.profile_status=1 AND (FIND_IN_SET('$time',availability_time) and status='1' and weekdays='$today_day') and NOT EXISTS($dpl1)";
		$query=$db->query($dql);
		if(mysqli_num_rows($query))
		{
		?>
			
  		<div class="carousel slide media-carousel" data-interval="false"  id="media">
        <div class="carousel-inner">
		
			<?php $red=mysqli_num_rows($query);
			
			$f=1;
			while($rowss=mysqli_fetch_assoc($query))
			{
				$data2=$db->get_user_data_byid($rowss['user_id']);
				$row2=mysqli_fetch_assoc($data2);
			?>
          <div class="item  <?php if($f==1){ echo "active"; } ?>">
		  <input type="radio" value="<?php echo $rowss['user_id']; ?>" name="user_booked" <?php if($f==1){ echo "checked"; } ?> class="user_val_book" style="display:none;" />
          	<h2 class="Portfolio_h2 chan_j1"><?php echo $f; ?> of <?php echo $red; ?> best matches</h2>
            	<div class="img_link_1 img_link_5">
		  <img src="profile/<?php echo $row2['u_img']; ?>">
		  <div class="img_link_cont">
		  	<h4><?php echo $row2['u_f_name']." ".$row2['u_l_name']; ?></h4>
		  	<div class="star"> 
								<?php
								$data1 = $db->getratingbyidavg($row2['user_id']);
					             $s2 = mysqli_fetch_assoc($data1);
								for($k=1; $k<=5; $k++){
								if($k <= $s2['rating'])
								{
								echo '<i class="fa fa-star active"></i>';
								}else{
								echo '<i class="fa fa-star-o"></i>';
								}
								}
								?>                         <span></span>
                      </div>
				<h4><?php echo $s2['review']; ?></h4>	  
               <h6 style="display:none;">Has made 5 other Snappr customers happy</h6>       
		  </div>
		</div>
		<h2 class="Portfolio_h2">Portfolio samples</h2>
		<div class="gallery user_img_list_1">
			<div class="row">
			<?php 
						$data3=$db->Cat_userimgByID($rowss['user_id']);
						while($row3=mysqli_fetch_assoc($data3))
						{
							?>
							<div class="col-sm-3">
						<a class="fancybox" rel="ligthbox" href="profile/<?php echo $row3['p_img']; ?>">
							    <img src="profile/<?php echo $row3['p_img']; ?>" alt="" />
							   </a>
						</div>
							<?php
						}
				?>
				
			</div> 
		</div>


          </div>
		  
		<?php $f++; } ?>
          
        </div> 
        <a data-slide="prev" onclick="return switch_user();" href="#media" class="left carousel-control">‹</a>        
        <a data-slide="next" href="#media" onclick="return switch_user();" class="right carousel-control">›</a>
      </div> 
		<?php } else { ?>
		<span class="alertmsg<?php echo $tabs; ?>" style="display:none;">No Photographer Available at <?php echo $vals; ?>, <?php echo $time; ?>.Please adjust your shoot timing..</span>
		
		<p class="alert alert-danger">No Photographer Available at <?php echo $vals; ?>, <?php echo $time; ?>.Please adjust your shoot timing.. <input type="hidden" value="" /></p>
		<?php } ?>
  	</div>
	
	<?php
	
	}
	else if($tabs==7)
	{
		unset($_SESSION['form_data']);
		foreach($_POST as $key=>$value)
		{
			$_SESSION['form_data'][$key]=$value;
		}
		//print_r($_SESSION['form_data']);
		?>
			<h1>Confirm your shoot details</h1>
			<h4>Other people are looking at shoots for a similar time and location
			<?php 
			$pack_data=$db->Get_packagesById($_POST['packages']);
			$pack_row=mysqli_fetch_assoc($pack_data);
			$amounts=$pack_row['p_price'];
			$currency='USD';
			$packages=$_POST['packages'];
			$data2=$db->get_user_data_byid($_SESSION['user_id']);
			$row2=mysqli_fetch_assoc($data2);
			
			
			$datauser_booked2=$db->get_user_data_byid($_POST['user_booked']);
			$user_booked=mysqli_fetch_assoc($datauser_booked2);
			
			?>
			<div class="button_pay">
			<div class="row">
			<div class="col-sm-6">
				<div id="paypal-button-container" class="btn btn-theme"></div>
			</div>
			<div class="col-sm-6">
			    
				<a href="javascript:void(0);" style="display:none;" class="btn btn-theme" data-toggle="modal" data-target="#new_payModal" > <img src="img/cradit-card.png"></a>
				<div class="radio img_link_1 btn btn-theme" onclick="window.location='process/process.php?action=payment_complete&pay_type=COD'" style="margin-top: 0px;">
				<label style="border:none;margin: 0;min-height: 30px;padding: 4px 9px 4px 0px;position: relative;"><img class="img_radu" style="height: 38px;left: 14px;top: 1px;width: 44px;" src="img/cod.png"><span style="display: inline-block;padding-top: 0px;position: relative;top: 1px;">Cash on Delivery</span></label>
				</div>
			</div>
			</div>		
			</div>
			<hr />
    
			<div class="img_link_1 total_rrr">
		<h3 style="text-align: left;font-weight: bold;font-size: 18px;margin-bottom: 26px;">Booking Amount: <span style="float:right">$<?php echo $amounts; ?></span></h3>
		</div>
			<div class="img_link_1" style="margin-bottom: 10px;">
			<div class="userrr_detail1">
				<p>
					<a href="javascript:void(0);"><i class="fa fa-envelope"></i> <?php echo $row2['u_email']; ?></a>
				</p>
				<p>
					<a href="javascript:void(0);"><i class="fa fa-mobile phonevalidation"></i><?php echo $row2['u_phone_number']; ?></a>
				</p>
				<p>
					<a href="javascript:void(0);"><i class="fa fa-map-marker"></i> <?php echo $_POST['address']; ?>, <?php echo $_POST['location_detail']; ?></a>
				</p>
				<p>
					<a href="javascript:void(0);"><i class="fa fa-calendar"></i><?php echo $_POST['booking_time']; ?>, <?php echo date('D d M Y',strtotime($_POST['booking_date'])); ?></a>
				</p>
			</div> 
		</div>
		<div class="img_link_1" style="margin-bottom: 10px;">
			<div class="userrr_detail1 pricing-detail">
				<!--<p>  
					<span class="pull-left">
						<a href="javascript:void(0);"><i class="fa fa-envelope"></i> <?php echo $pack_row['p_title']; ?></a>
					</span>
		<span class="pull-right">      
			$<?php echo $pack_row['p_price']; ?>
		</span>


		</p> -->
		
		<div class="row">
		<div class="col-sm-6 col-sm-offset-3">
			   <label style="padding:10px;">
				<?php 
				if ($pack_row['p_time']==30){
					$ds=1;
				}
				else if($pack_row['p_time']<6)
				{
					$ds=$pack_row['p_time'];
				}
				else 
				{
					$ds=6;
				}
				?>
				<img src="img/1.png">
					<h2><?php echo $pack_row['p_title'];?></h2>
					<?php if ($pack_row['p_time']==30){ ?>
						<h4><?php echo $pack_row['p_time'];?> min									   
						| $<?php echo $pack_row['p_price'];?></h4>
					<?php } else{ ?>
						<h4><?php echo $pack_row['p_time'];?> hr									   
						| $<?php echo $pack_row['p_price'];?></h4>
					<?php } ?>
					<div class="decsc-pricing center-pac-text">	
					<?php echo html_entity_decode($pack_row['p_description']);?>  
					<p>Image enhancement included</p>
				</div>
			 </label>
			 </div>
			 </div>
		
	</div>
	<hr />
    <h3 style="text-align: left;font-weight: bold;font-size: 18px;">Expert Details:</h3>
	<div class="sconddd_us">
	<div class="sconddd_us">
		<img src="profile/<?php echo $user_booked['u_img']; ?>">
		<div class="img_link_cont">
		  	<h4><?php echo $user_booked['u_f_name']." ".$user_booked['u_l_name']; ?></h4>
		  	<div class="star"> 
								<i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i>                        <span></span>
                      </div>
               <h6 style="display:none;">Has made 5 other Snappr customers happy</h6>       
		  </div>
		</div>
		</div>&@<?php echo $amounts; ?>

		<?php
	}
}

else if(isset($_REQUEST['action']) && $_REQUEST['action']=='contactus')
{
	extract($_REQUEST);
        
		 $sql = "INSERT INTO  tbl_contactus SET name='".$name."',email='".$email."',phone='".$phone."',message='".htmlentities($message,ENT_QUOTES)."' ";
		$result = $db->query($sql); 
		if($result==true)
		{
	        $data1=$db->get_admin_data();
			$r=mysqli_fetch_assoc($data1);
			$email = $r['mail_email'];
	        $subject ="Phoshot: You Have a new Contect Request"; 
			$contant= '<p class="text-center">Name:- '.$_REQUEST['name'].'</p>';
			$contant.='<p class="text-center">Email:-'.$_REQUEST['email'].'</p>';
			$contant.='<p class="text-center">Phone Number:-'.$_REQUEST['phone'].'</p>';
			$contant.='<p class="text-center">Message:-'.$_REQUEST['message'].'</p>';
			
			$test = $db->MailSend($email,$subject,$contant);
			$_SESSION['suc_msg'] = "Success: Message has been sent Successfully.";
			
		}else
		{
			$_SESSION['suc_msg'] = "Error:Something went wrong .";
			
		}
		header('location:../thank-you.php');
}

else if(isset($_REQUEST['action']) && $_REQUEST['action']=='payment_complete')
{
	$form_data=$_SESSION['form_data'];
	
	if($form_data['packages'])
	{ 
	if($_REQUEST['pay_type']=='COD')
	{
	$pay_type='COD';	
	}
	else
	{
	$pay_type='paypal';
	} 
	$data12=$db->get_user_data_byid($_SESSION["user_id"]);
	$row12=mysqli_fetch_assoc($data12);
	$data2=$db->Get_packagesById($form_data['packages']);
	$row2=mysqli_fetch_assoc($data2);
	if(isset($_REQUEST['type']) && $_REQUEST['type']=='Credit_card')
	{
	    
	    require_once("../lib/Twocheckout.php");

        Twocheckout::privateKey('17E4CFFD-4FF6-43B8-8207-B4D7D9874156'); //Private Key
        Twocheckout::sellerId('901399743'); // 2Checkout Account Number
        Twocheckout::sandbox(true);
        try {
            $charge = Twocheckout_Charge::auth(array(
                "merchantOrderId" => rand(9999,10000),
                "token"      => $_POST['token'],
                "currency"   => 'USD',
                "total"      => $row2['p_price'],
                "billingAddr" => array(
                    "name" => $row12['u_f_name'],
                    "addrLine1" => $form_data['address'],
                    "city" => 'Columbus',
                    "state" => 'OH',
                    "zipCode" => '43123',
                    "country" => 'USA',
                    "email" => $row12['u_email'],
                    "phoneNumber" => '555-555-5555'
                )
            ));
        
            if ($charge['response']['responseCode'] == 'APPROVED') {
                $pay_type='Credit_card';
        
            }
        } catch (Twocheckout_Error $e) {
            /*print_r($e->getMessage());
            print_r($charge);*/
			echo "0@@".'Error! '.$e->getMessage();
            $_SESSION['succ_msg']='<p class="alert alert-danger">Payment Failed! '.$e->getMessage().'.</p>';
            //header('location:../book.php');
            die;
        }
	
	}
	$cost=$row2['p_price'];
	$ins="insert into my_bookings set shot_type='".$form_data['shot_type']."',category='".$form_data['category']."',address='".$form_data['address']."',location_detail='".$form_data['location_detail']."',shot_time='".$form_data['shot_time']."',packages='".$form_data['packages']."',booking_date='".date('Y-m-d',strtotime($form_data['booking_date']))."',booking_time='".$form_data['booking_time']."',user_booked='".$form_data['user_booked']."',pay_by='$pay_type',cdate='".date('Y-m-d H:i:s')."',booked_by='".$_SESSION["user_id"]."',amount='".$row2['p_price']."'";
	$result = $db->query($ins);
	$newid = $db->insert_id();
	$newid ="1000".$newid;
	if($result)
	{
	    $data2=$db->Get_packagesById($form_data['packages']);
		$row2=mysqli_fetch_assoc($data2);
		if ($row2['p_time']==30){
			$time="min";
		}
		else
		{
			$time="hr";
		}
		
		$dat=date('Y-m-d',strtotime($form_data['booking_date']));
		$data1=$db->get_user_data_byid($form_data['user_booked']);
		$row1=mysqli_fetch_assoc($data1);
		
		$data12=$db->get_user_data_byid($_SESSION["user_id"]);
		$row12=mysqli_fetch_assoc($data12);
		
		$u_name=$row1['u_f_name'];
		$to=$row1['u_email'];
		$subject='PhoShot: New Booking Confirmation';
		$contant= '<p>This mail is inform you that, You have been booked by <b>'.$row12['u_f_name'].'</b> '.$dat.' at '.$form_data['booking_time'].'</p>';
		$contant.='<p><b>Booking Info</b></p>';
		$contant.='<p><b>BookedID #:</b> '.$newid.'</p>';
		$contant.='<p><b>Booked Package:</b> '.$row2['p_title'].'</p>';
		$contant.='<p><b>Shoot Type:</b> '.$row2['p_time'].' '.$time.'</p>';
		$contant.='<p><b>Booking Date&TIme:</b> '.date('Y-m-d',strtotime($form_data['booking_date'])).','.$form_data['booking_time'].'</p>';
		$contant.='<p><b>TotalCost:$</b> '.$cost.'</p>';
		$contant.='<p><b>Payment method:</b> '.$pay_type.'</p>';
		$contant.='<p><b>Address:</b> '.$form_data['address'].', '.$form_data['location_detail'].'</p>';
		$contant.='<p>For More detail please login and check your booking .</p></p>';
	    $db->MailSend($to,$subject,$contant);
	    
	    $data1=$db->get_user_data_byid($_SESSION["user_id"]);
		$row1=mysqli_fetch_assoc($data1);
		$to=$row1['u_email'];
		$subject='PhoShot: New Booking Confirmation';
		$contant= '<p>This mail is inform you that, You have been booked to <b>'.$u_name.'</b> on '.$dat.' at '.$form_data['booking_time'].'</p>';
		$contant.='<p><b>Booking Info</b></p>';
		$contant.='<p><b>BookedID #:</b> '.$newid.'</p>';
		$contant.='<p><b>Package:</b> '.$row2['p_title'].'</p>';
		$contant.='<p><b>Shoot Type:</b> '.$row2['p_time'].' '.$time.'</p>';
		$contant.='<p><b>Booking Date&TIme:</b> '.date('Y-m-d',strtotime($form_data['booking_date'])).','.$form_data['booking_time'].'</p>';
		$contant.='<p><b>TotalCost:$</b> '.$cost.'</p>';
		$contant.='<p><b>Payment method:</b> '.$pay_type.'</p>';
		$contant.='<p><b>Address:</b> '.$form_data['address'].', '.$form_data['location_detail'].'</p>';
		$contant.='<p>For More detail please login and check your booking info.</p>';
	    $db->MailSend($to,$subject,$contant);
		
		
		$data1dd=$db->get_admin_data();
		$row1dd=mysqli_fetch_assoc($data1dd);
		$to=$row1dd['mail_email'];
		$subject='PhoShot: New Booking Confirmation';
		$contant= '<p>This mail is inform you that,<b>'.$row12['u_f_name'].'</b> has been booked  <b>'.$u_name.'</b> expert  for '.$dat.' at '.$form_data['booking_time'].'</p>';
		$contant.='<p><b>Booking Info</b></p>';
		$contant.='<p><b>BookedID #:</b> '.$newid.'</p>';
		$contant.='<p><b>Package:</b> '.$row2['p_title'].'</p>';
		$contant.='<p><b>Shoot Type:</b> '.$row2['p_time'].' '.$time.'</p>';
		$contant.='<p><b>Booking Date&TIme:</b> '.date('Y-m-d',strtotime($form_data['booking_date'])).','.$form_data['booking_time'].'</p>';
		$contant.='<p><b>TotalCost:$</b> '.$cost.'</p>';
		$contant.='<p><b>Payment method:</b> '.$pay_type.'</p>';
		$contant.='<p><b>Address:</b> '.$form_data['address'].', '.$form_data['location_detail'].'</p>';
		$contant.='<p>For More detail please login and check the booking info.</p>';
	    $db->MailSend($to,$subject,$contant);
		
		
		unset($_SESSION['form_data']);
		
		$_SESSION['succ_msg']='<p class="alert alert-success">Success! Your booking has been done.</p>';
		header('location:../home.php');
		
		
	} 
	else 
	{
		echo"2";
		$_SESSION['succ_msg']='<p class="alert alert-danger">Error! Something Went Wrong.</p>';
		header('location:../book.php');
		
		
	}
	}
	else
	{
		echo"3";
		$_SESSION['succ_msg']='<p class="alert alert-danger">Error! Something Went Wrong.</p>';
		header('location:../book.php');
		
	}
	
	//header('location:../book.php');
	
}

else if(isset($_REQUEST['action']) && $_REQUEST['action']=='rating')
{
       
		$rating = $_REQUEST['rating'];
		$review = $_REQUEST['review'];
		$review_by = $_REQUEST['review_by'];
		$review_to = $_REQUEST['review_to'];
		$orderid = $_REQUEST['orderid'];
		
		$usersdata=$db->getbookedbyid($orderid);
        $users=mysqli_fetch_array($usersdata);
		 $amount= $users['amount']; 
		$admindata= $db->get_admin_data();
		$admin = mysqli_fetch_assoc($admindata);
		  $percent= $admin['admin_percent'];	 
		  $new_amount = ($amount / 100) * $percent;
		  $final_amount = $amount - $new_amount;
		
		  $u_email = $_REQUEST['u_email'];
		 $sql = "INSERT INTO tbl_rating SET rating='$rating',review='$review',review_by='$review_by' ,review_to='$review_to',orderid='$orderid' ";
		 $result = $db->query($sql); 
		 $sql1 = "UPDATE user SET u_wallet=(u_wallet+$final_amount) WHERE user_id='$review_to'";
		$result1 = $db->query($sql1);
		 $sql2 = "UPDATE my_bookings SET status='1' WHERE id='$orderid'";
		$result2 = $db->query($sql2);
		if($result==true)
		{   
	        $da =$db->getuser($review_to);
			$s1 = mysqli_fetch_assoc($da);
			 $das =$db->getuserbyid($review_by);
			 $da2 = mysqli_fetch_assoc($das);
	         $subject ="Phoshot: Job Completed & Feeback Left From Client!"; 
		     $contant = $s1['u_f_name'];
		     $contant .='<p class="text-center"> Your Booking (#1000'.$orderid.') has been completed successfully and '.$da2['u_f_name']. ' has been rated your profile.<p>';
			  $test = $db->MailSend($u_email,$subject,$contant);
			$data1dd=$db->get_admin_data();
			$row1dd=mysqli_fetch_assoc($data1dd);
			$to=$row1dd['mail_email'];
			$subject ="Phoshot: Job Completed & Feeback Left From Client!"; 
		    $contant = $s1['u_f_name'];
		    $contant .='<p class="text-center"> This mail to inform you that, Booking (#1000'.$orderid.') has been completed successfully and Customer: '.$da2['u_f_name']. ' has been  rated '.$s1['u_f_name'].' expert  profile.<p>';
			$test = $db->MailSend($to,$subject,$contant);
			  
			  
	       
			$_SESSION['suc_msg'] = "Success:Your Rating has been completed successfully .";
			
		}else
		{
	        
			$_SESSION['suc_msg'] = "Something went wrong .";
			
		}
		header('location:../home.php');
}
else if(isset($_REQUEST['action']) && $_REQUEST['action']=='ratingafterdone')
{
       
		$rating = $_REQUEST['rating'];
		$review = $_REQUEST['review'];
		$review_by = $_REQUEST['review_by'];
		$review_to = $_REQUEST['review_to'];
		$orderid = $_REQUEST['orderid'];
	    $u_email = $_REQUEST['u_email'];
		$sql = "INSERT INTO tbl_rating SET rating='$rating',review='$review',review_by='$review_by' ,review_to='$review_to',orderid='$orderid' ";
		$result = $db->query($sql); 
		
		if($result==true)
		{   
	        $da =$db->getuser($review_to);
			$s1 = mysqli_fetch_assoc($da);
			 $das =$db->getuserbyid($review_by);
			 $da2 = mysqli_fetch_assoc($das);
	         $subject ="Phoshot: Feeback Left From Client!"; 
		     $contant = $s1['u_f_name'];
		     $contant .='<p class="text-center"> This mail to inform you that '.$da2['u_f_name']. ' has been  rated your profile for Booking(#1000'.$orderid.').<p>';
			  $test = $db->MailSend($u_email,$subject,$contant);
			
			
			$data1dd=$db->get_admin_data();
			$row1dd=mysqli_fetch_assoc($data1dd);
			$to=$row1dd['mail_email'];
			$subject ="Phoshot: Feeback Left From Client!"; 
		     $contant = $s1['u_f_name'];
		     $contant .='<p class="text-center"> This mail to inform you that Customer: '.$da2['u_f_name']. ' has been  rated '.$s1['u_f_name'].' expert  profile for Booking(#1000'.$orderid.').<p>';
			  $test = $db->MailSend($to,$subject,$contant);
			
			
			
	       
			$_SESSION['suc_msg'] = "Success:Your Rating has been completed successfully .";
			
		}else
		{
	        
			$_SESSION['suc_msg'] = "Something went wrong .";
			
		}
		header('location:../home.php');
}
else if(isset($_REQUEST['action']) && $_REQUEST['action'] == 'seeimages')
{
	$dr=$db->Getexpertcatimages($_REQUEST['id']);
	while($q = mysqli_fetch_array($dr)){
								?>
								<li id="list<?php echo $q['p_id'];?>"><div class="img-wrap"> <span class="close" style="width: 16%;text-align: center;font-size: 13px;" onclick="del_area_img(<?php echo $q['p_id'];?>);"><i style="color:white;    margin-top: -5px;" class="fa fa-times" aria-hidden="true"></i></span> 
								<img src="profile/<?php echo $q['p_img'];?>" class="thumb"  alt="Photo"   /></div><input name="filesets_<?php echo $_REQUEST['id'];?>[]" value="<?php echo $q['p_img'];?>" type="hidden"  />
								
								</li>
								
								<?php }
}
else if(isset($_REQUEST['action']) && $_REQUEST['action'] == 'withdrawalamount')
{
	$user_id=$_REQUEST['user_id'];
	$acount_holder_name = $_REQUEST['acount_holder_name'];
	$acount_no = $_REQUEST['acount_no'];
	$routing_no = $_REQUEST['routing_no'];
	$amount = $_REQUEST['amount'];
	$bank_name = $_REQUEST['bank_name'];
	$user = $db->get_user_data_byid($_SESSION['user_id']);
	$row = mysqli_fetch_assoc($user);
	$u_wallet= $row['u_wallet'];
	$wallet_amount=$u_wallet - $amount;
	
	 $sql="insert into tbl_tranction set acount_holder_name='$acount_holder_name',acount_no='$acount_no',routing_no='$routing_no',amount='$amount',bank_name='$bank_name',user_id='$user_id', t_status='0'"; 
	$data=$db->query($sql);
	
	$data1dd=$db->get_admin_data();
			$row1dd=mysqli_fetch_assoc($data1dd);
			$to=$row1dd['mail_email'];
			$subject ="Phoshot: Withdrawal Request From Expert!"; 
		     $contant = $s1['u_f_name'];
		     $contant .='<p class="text-center"> This mail to inform you that Expert: '.$row['u_f_name']. ' has been  subbmited a Withdrawal Request.<p>';
			  $test = $db->MailSend($to,$subject,$contant);
			
	
	
	//$sql1="update user set u_wallet='$wallet_amount' where user_id='$user_id'";
	//$data1=$db->query($sql1); 
	if($data)
	{
		$_SESSION['suc_msg'] = '<div class="alert alert-success">Success: Your Withdrawal  request has been subbmited successfully and the funds will be transfered to your account within 3-5 business days/</div>';

	}
	else 
	{
		$_SESSION['suc_msg'] = '<div class="alert alert-danger">Error: Try again sometime!</div>';
	}
        $db->redirect('../wallet.php');
}

else
{
	echo '<pre>';
	//PRINT_R($_SESSION['form_data']);	
	print_r($_REQUEST);
	print_r($_FILES);
	echo '<h1>Your Action Is Wrong</h1>';
}



?>